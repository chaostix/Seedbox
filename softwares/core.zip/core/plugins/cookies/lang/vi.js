﻿

 theUILang.cookiesDesc = "Cookies (Định dạng: host|cookie1;cookie2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();