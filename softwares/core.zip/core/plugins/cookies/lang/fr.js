﻿/*
 * PLUGIN COOKIES
 *
 * File Name: fr.js
 * 	French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.cookiesDesc = "Cookies (Format: domaine|nom1=contenu1;nom2=contenu2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();