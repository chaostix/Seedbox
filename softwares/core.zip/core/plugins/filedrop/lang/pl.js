﻿/*
 * PLUGIN FILEDROP
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Your browser does not support HTML5 file uploads. Plugin was disabled.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Too many files. Must be <= ";
 theUILang.fileTooLarge 	= "is too large. Please upload files up to";

thePlugins.get("filedrop").langLoaded();