﻿

 theUILang.getData		= "Verkrijg data";
 theUILang.cantAccessData	= "Web-server user heeft geen toegang tot de data van deze torrent.";

thePlugins.get("data").langLoaded();