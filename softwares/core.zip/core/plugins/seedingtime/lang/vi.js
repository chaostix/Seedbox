﻿

 theUILang.seedingTime		= "Đã hoàn thành";
 theUILang.addTime		= "Đã thêm vào";

thePlugins.get("seedingtime").langLoaded();