﻿

 theUILang.seedingTime		= "Ukończono";
 theUILang.addTime		= "Dodano";

thePlugins.get("seedingtime").langLoaded();
