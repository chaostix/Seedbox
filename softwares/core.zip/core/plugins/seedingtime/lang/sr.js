﻿

 theUILang.seedingTime		= "Завршено";
 theUILang.addTime		= "Added";

thePlugins.get("seedingtime").langLoaded();
