﻿

 theUILang.seedingTime		= "Finished";
 theUILang.addTime		= "Toegevoegd";

thePlugins.get("seedingtime").langLoaded();