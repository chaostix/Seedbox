﻿

 theUILang.seedingTime		= "Завершено";
 theUILang.addTime		= "Додано";

thePlugins.get("seedingtime").langLoaded();