﻿

 theUILang.seedingTime		= "Завершен";
 theUILang.addTime		= "Добавлен";

thePlugins.get("seedingtime").langLoaded();