﻿
// Contributed by art.spb, December 2009.

theUILang.countryName = "Ülke";

theUILang.country = new Array();

theUILang.country[ "ad" ] = "Andorra";
theUILang.country[ "ae" ] = "Birleşik Arap Emirlikleri";
theUILang.country[ "af" ] = "Afganistan";
theUILang.country[ "ag" ] = "Antigua ve Barbuda";
theUILang.country[ "ai" ] = "Anguilla";
theUILang.country[ "al" ] = "Arnavutluk";
theUILang.country[ "am" ] = "Ermenistan";
theUILang.country[ "an" ] = "Hollanda Antilleri";
theUILang.country[ "ao" ] = "Angola";
theUILang.country[ "aq" ] = "Antarktika";
theUILang.country[ "ar" ] = "Arjantin";
theUILang.country[ "as" ] = "Amerikan Samoası";
theUILang.country[ "at" ] = "Avusturya";
theUILang.country[ "au" ] = "Avustralya";
theUILang.country[ "aw" ] = "Aruba";
theUILang.country[ "ax" ] = "Åland Adaları";
theUILang.country[ "az" ] = "Azerbaycan";

theUILang.country[ "ba" ] = "Bosna Hersek";
theUILang.country[ "bb" ] = "Barbados";
theUILang.country[ "bd" ] = "Bangladeş";
theUILang.country[ "be" ] = "Belçika";
theUILang.country[ "bf" ] = "Burkina Faso";
theUILang.country[ "bg" ] = "Bulgaristan";
theUILang.country[ "bh" ] = "Bahreyn";
theUILang.country[ "bi" ] = "Burundi";
theUILang.country[ "bj" ] = "Benin";
theUILang.country[ "bm" ] = "Bermuda";
theUILang.country[ "bn" ] = "Brunei";
theUILang.country[ "bo" ] = "Bolivya";
theUILang.country[ "br" ] = "Brezilya";
theUILang.country[ "bs" ] = "Bahamas";
theUILang.country[ "bt" ] = "Bhutan";
theUILang.country[ "bv" ] = "Bouvet Adası";
theUILang.country[ "bw" ] = "Botsvana";
theUILang.country[ "by" ] = "Beyaz Rusya";
theUILang.country[ "bz" ] = "Belize";

theUILang.country[ "ca" ] = "Kanada";
theUILang.country[ "cc" ] = "Cocos Adaları";
theUILang.country[ "cd" ] = "Kongo-Kinşasa";
theUILang.country[ "cf" ] = "Orta Afrika Cumhuriyeti";
theUILang.country[ "cg" ] = "Kongo-Brazzaville";
theUILang.country[ "ch" ] = "İsviçre";
theUILang.country[ "ci" ] = "Fildişi Sahili";
theUILang.country[ "ck" ] = "Cook Adaları";
theUILang.country[ "cl" ] = "Şili";
theUILang.country[ "cm" ] = "Kamerun";
theUILang.country[ "cn" ] = "Çin";
theUILang.country[ "co" ] = "Kolombiya";
theUILang.country[ "cr" ] = "Kosta Rika";
theUILang.country[ "cu" ] = "Küba";
theUILang.country[ "cv" ] = "Cape Verde";
theUILang.country[ "cx" ] = "Christmas Adası";
theUILang.country[ "cy" ] = "Kıbrıs";
theUILang.country[ "cz" ] = "Çek Cumhuriyeti";

theUILang.country[ "de" ] = "Almanya";
theUILang.country[ "dj" ] = "Cibuti";
theUILang.country[ "dk" ] = "Danimarka";
theUILang.country[ "dm" ] = "Dominika";
theUILang.country[ "do" ] = "Dominik Cumhuriyeti";
theUILang.country[ "dz" ] = "Cezayir";

theUILang.country[ "ec" ] = "Ekvador";
theUILang.country[ "ee" ] = "Estonya";
theUILang.country[ "eg" ] = "Mısır";
theUILang.country[ "eh" ] = "Batı Sahra";
theUILang.country[ "er" ] = "Eritre";
theUILang.country[ "es" ] = "İspanya";
theUILang.country[ "et" ] = "Etiyopya";
theUILang.country[ "eu" ] = "Avrupa Birliği";

theUILang.country[ "fi" ] = "Finlandiya";
theUILang.country[ "fj" ] = "Fiji";
theUILang.country[ "fk" ] = "Falkland Adaları";
theUILang.country[ "fm" ] = "Mikronezya";
theUILang.country[ "fo" ] = "Faroe Adaları";
theUILang.country[ "fr" ] = "Fransa";

theUILang.country[ "ga" ] = "Gabon";
theUILang.country[ "gb" ] = "Birleşik Krallık";
theUILang.country[ "gd" ] = "Grenada";
theUILang.country[ "ge" ] = "Georgia";
theUILang.country[ "gf" ] = "Fransız Guyanası";
theUILang.country[ "gg" ] = "Guernsey";
theUILang.country[ "gh" ] = "Gana";
theUILang.country[ "gi" ] = "Cebelitarık";
theUILang.country[ "gl" ] = "Grönland";
theUILang.country[ "gm" ] = "Gambiya";
theUILang.country[ "gn" ] = "Gine";
theUILang.country[ "gp" ] = "Guadeloupe";
theUILang.country[ "gq" ] = "Ekvator Ginesi";
theUILang.country[ "gr" ] = "Yunanistan";
theUILang.country[ "gs" ] = "Güney Georgia ve Güney Sandwich Adaları";
theUILang.country[ "gt" ] = "Guatemala";
theUILang.country[ "gu" ] = "Guam";
theUILang.country[ "gw" ] = "Gine-Bissau";
theUILang.country[ "gy" ] = "Guyana";

theUILang.country[ "hk" ] = "Hong Kong";
theUILang.country[ "hm" ] = "Heard Adası ve McDonald Adaları";
theUILang.country[ "hn" ] = "Honduras";
theUILang.country[ "hr" ] = "Hırvatistan";
theUILang.country[ "ht" ] = "Haiti";
theUILang.country[ "hu" ] = "Macaristan";

theUILang.country[ "id" ] = "Endonezya";
theUILang.country[ "ie" ] = "İrlanda";
theUILang.country[ "il" ] = "İsrail";
theUILang.country[ "im" ] = "Isle of Man";
theUILang.country[ "in" ] = "Hindistan";
theUILang.country[ "io" ] = "İngiliz Hint Okyanusu Toprakları";
theUILang.country[ "iq" ] = "Irak";
theUILang.country[ "ir" ] = "İran";
theUILang.country[ "is" ] = "İzlanda";
theUILang.country[ "it" ] = "İtalya";

theUILang.country[ "je" ] = "Jersey";
theUILang.country[ "jm" ] = "Jamaika";
theUILang.country[ "jo" ] = "Ürdün";
theUILang.country[ "jp" ] = "Japonya";

theUILang.country[ "ke" ] = "Kenya";
theUILang.country[ "kg" ] = "Kırgızistan";
theUILang.country[ "kh" ] = "Kamboçya";
theUILang.country[ "ki" ] = "Kiribati";
theUILang.country[ "km" ] = "Komorlar";
theUILang.country[ "kn" ] = "Saint Kitts ve Nevis";
theUILang.country[ "kp" ] = "Kuzey Kore";
theUILang.country[ "kr" ] = "Güney Kore";
theUILang.country[ "kw" ] = "Kuveyt";
theUILang.country[ "ky" ] = "Cayman Adaları";
theUILang.country[ "kz" ] = "Kazakistan";

theUILang.country[ "la" ] = "Laos";
theUILang.country[ "lb" ] = "Lübnan";
theUILang.country[ "lc" ] = "Saint Lucia";
theUILang.country[ "li" ] = "Liechtenstein";
theUILang.country[ "lk" ] = "Sri Lanka";
theUILang.country[ "lr" ] = "Liberya";
theUILang.country[ "ls" ] = "Lesoto";
theUILang.country[ "lt" ] = "Litvanya";
theUILang.country[ "lu" ] = "Lüksemburg";
theUILang.country[ "lv" ] = "Letonya";
theUILang.country[ "ly" ] = "Libya";

theUILang.country[ "ma" ] = "Fas";
theUILang.country[ "mc" ] = "Monako";
theUILang.country[ "md" ] = "Moldova";
theUILang.country[ "me" ] = "Karadağ";
theUILang.country[ "mg" ] = "Madagaskar";
theUILang.country[ "mh" ] = "Marshall Adaları";
theUILang.country[ "mk" ] = "Makedonya";
theUILang.country[ "ml" ] = "Mali";
theUILang.country[ "mm" ] = "Myanmar";
theUILang.country[ "mn" ] = "Moğolistan";
theUILang.country[ "mo" ] = "Macao";
theUILang.country[ "mp" ] = "Kuzey Mariana Adaları";
theUILang.country[ "mq" ] = "Martinik";
theUILang.country[ "mr" ] = "Moritanya";
theUILang.country[ "ms" ] = "Montserrat";
theUILang.country[ "mt" ] = "Malta";
theUILang.country[ "mu" ] = "Mauritius";
theUILang.country[ "mv" ] = "Maldivler";
theUILang.country[ "mw" ] = "Malavi";
theUILang.country[ "mx" ] = "Meksika";
theUILang.country[ "my" ] = "Malezya";
theUILang.country[ "mz" ] = "Mozambik";

theUILang.country[ "na" ] = "Namibya";
theUILang.country[ "nc" ] = "Yeni Kaledonya";
theUILang.country[ "ne" ] = "Nijer";
theUILang.country[ "nf" ] = "Norfolk Adası";
theUILang.country[ "ng" ] = "Nijerya";
theUILang.country[ "ni" ] = "Nikaragua";
theUILang.country[ "nl" ] = "Hollanda";
theUILang.country[ "no" ] = "Norveç";
theUILang.country[ "np" ] = "Nepal";
theUILang.country[ "nr" ] = "Nauru";
theUILang.country[ "nu" ] = "Niue";
theUILang.country[ "nz" ] = "Yeni Zelanda";

theUILang.country[ "om" ] = "Umman";

theUILang.country[ "pa" ] = "Panama";
theUILang.country[ "pe" ] = "Peru";
theUILang.country[ "pf" ] = "Fransız Polinezyası";
theUILang.country[ "pg" ] = "Papua Yeni Gine";
theUILang.country[ "ph" ] = "Filipinler";
theUILang.country[ "pk" ] = "Pakistan";
theUILang.country[ "pl" ] = "Polonya";
theUILang.country[ "pm" ] = "Saint Pierre ve Miquelon";
theUILang.country[ "pn" ] = "Pitcairn";
theUILang.country[ "pr" ] = "Puerto Rico";
theUILang.country[ "ps" ] = "Filistin";
theUILang.country[ "pt" ] = "Portekiz";
theUILang.country[ "pw" ] = "Palau";
theUILang.country[ "py" ] = "Paraguay";

theUILang.country[ "qa" ] = "Katar";

theUILang.country[ "re" ] = "Réunion";
theUILang.country[ "ro" ] = "Romanya";
theUILang.country[ "rs" ] = "Sırbistan";
theUILang.country[ "ru" ] = "Rusya";
theUILang.country[ "rw" ] = "Ruanda";

theUILang.country[ "sa" ] = "Suudi Arabistan";
theUILang.country[ "sb" ] = "Solomon Adaları";
theUILang.country[ "sc" ] = "Seyşel Adaları";
theUILang.country[ "sd" ] = "Sudan";
theUILang.country[ "se" ] = "İsveç";
theUILang.country[ "sg" ] = "Singapur";
theUILang.country[ "sh" ] = "Saint Helena";
theUILang.country[ "si" ] = "Slovenya";
theUILang.country[ "sj" ] = "Svalbard ve Jan Mayen";
theUILang.country[ "sk" ] = "Slovakya";
theUILang.country[ "sl" ] = "Sierra Leone";
theUILang.country[ "sm" ] = "San Marino";
theUILang.country[ "sn" ] = "Senegal";
theUILang.country[ "so" ] = "Somali";
theUILang.country[ "sr" ] = "Surinam";
theUILang.country[ "ss" ] = "Güney Sudan";
theUILang.country[ "st" ] = "Sao Tome ve Principe";
theUILang.country[ "sv" ] = "El Salvador";
theUILang.country[ "sy" ] = "Suriye";
theUILang.country[ "sz" ] = "Svaziland";

theUILang.country[ "tc" ] = "Turks ve Caicos Adaları";
theUILang.country[ "td" ] = "Çad";
theUILang.country[ "tf" ] = "Fransız Güney Toprakları";
theUILang.country[ "tg" ] = "Togo";
theUILang.country[ "th" ] = "Tayland";
theUILang.country[ "tj" ] = "Tacikistan";
theUILang.country[ "tk" ] = "Tokelau";
theUILang.country[ "tl" ] = "Doğu Timor";
theUILang.country[ "tm" ] = "Türkmenistan";
theUILang.country[ "tn" ] = "Tunus";
theUILang.country[ "to" ] = "Tonga";
theUILang.country[ "tr" ] = "Türkiye";
theUILang.country[ "tp" ] = "Portekizce Timor";
theUILang.country[ "tt" ] = "Trinidad ve Tobago";
theUILang.country[ "tv" ] = "Tuvalu";
theUILang.country[ "tw" ] = "Tayvan";
theUILang.country[ "tz" ] = "Tanzanya";

theUILang.country[ "ua" ] = "Ukrayna";
theUILang.country[ "ug" ] = "Uganda";
theUILang.country[ "uk" ] = "Birleşik Krallık";
theUILang.country[ "um" ] = "Amerika Birleşik Devletleri Küçük Dış Adaları";
theUILang.country[ "un" ] = "Bilinmeyen";
theUILang.country[ "us" ] = "Amerika Birleşik Devletleri";
theUILang.country[ "uy" ] = "Uruguay";
theUILang.country[ "uz" ] = "Özbekistan";

theUILang.country[ "va" ] = "Vatikan";
theUILang.country[ "vc" ] = "Saint Vincent ve Grenadinler";
theUILang.country[ "ve" ] = "Venezuela";
theUILang.country[ "vg" ] = "İngiliz Virgin Adaları";
theUILang.country[ "vi" ] = "ABD Virgin Adaları";
theUILang.country[ "vn" ] = "Viet Nam";
theUILang.country[ "vu" ] = "Vanuatu";

theUILang.country[ "wf" ] = "Wallis ve Futuna";
theUILang.country[ "ws" ] = "Samoa";

theUILang.country[ "ye" ] = "Yemen";
theUILang.country[ "yt" ] = "Mayotte";

theUILang.country[ "za" ] = "Güney Afrika";
theUILang.country[ "zm" ] = "Zambiya";
theUILang.country[ "zw" ] = "Zimbabve";

thePlugins.get("geoip").langLoaded();