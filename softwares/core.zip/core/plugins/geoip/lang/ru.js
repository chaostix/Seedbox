﻿
// Contributed by art.spb, December 2009.

theUILang.countryName = "Страна";

theUILang.country = new Array();

theUILang.country[ "ad" ] = "Андорра";
theUILang.country[ "ae" ] = "ОАЭ";
theUILang.country[ "af" ] = "Афганистан";
theUILang.country[ "ag" ] = "Антигуа и Барбуда";
theUILang.country[ "ai" ] = "Ангилья";
theUILang.country[ "al" ] = "Албания";
theUILang.country[ "am" ] = "Армения";
theUILang.country[ "an" ] = "Нидерландские Антильские острова";
theUILang.country[ "ao" ] = "Ангола";
theUILang.country[ "aq" ] = "Антарктида";
theUILang.country[ "ar" ] = "Аргентина";
theUILang.country[ "as" ] = "Американское Самоа";
theUILang.country[ "at" ] = "Австрия";
theUILang.country[ "au" ] = "Австралия";
theUILang.country[ "aw" ] = "Аруба";
theUILang.country[ "ax" ] = "Аландские острова";
theUILang.country[ "az" ] = "Азербайджан";

theUILang.country[ "ba" ] = "Босния и Герцеговина";
theUILang.country[ "bb" ] = "Барбадос";
theUILang.country[ "bd" ] = "Бангладеш";
theUILang.country[ "be" ] = "Бельгия";
theUILang.country[ "bf" ] = "Буркина Фасо";
theUILang.country[ "bg" ] = "Болгария";
theUILang.country[ "bh" ] = "Бахрейн";
theUILang.country[ "bi" ] = "Бурунди";
theUILang.country[ "bj" ] = "Бенин";
theUILang.country[ "bm" ] = "Бермуды";
theUILang.country[ "bn" ] = "Бруней";
theUILang.country[ "bo" ] = "Боливия";
theUILang.country[ "br" ] = "Бразилия";
theUILang.country[ "bs" ] = "Багамы";
theUILang.country[ "bt" ] = "Бутан";
theUILang.country[ "bv" ] = "Остров Буве";
theUILang.country[ "bw" ] = "Ботсвана";
theUILang.country[ "by" ] = "Белоруссия";
theUILang.country[ "bz" ] = "Белиз";

theUILang.country[ "ca" ] = "Канада";
theUILang.country[ "cc" ] = "Кокосовые острова";
theUILang.country[ "cd" ] = "Конго-Киншаса";
theUILang.country[ "cf" ] = "ЦАР";
theUILang.country[ "cg" ] = "Конго-Браззавиль";
theUILang.country[ "ch" ] = "Швейцария";
theUILang.country[ "ci" ] = "Кот-д’Ивуар";
theUILang.country[ "ck" ] = "Острова Кука";
theUILang.country[ "cl" ] = "Чили";
theUILang.country[ "cm" ] = "Камерун";
theUILang.country[ "cn" ] = "Китай";
theUILang.country[ "co" ] = "Колумбия";
theUILang.country[ "cr" ] = "Коста-Рика";
theUILang.country[ "cu" ] = "Куба";
theUILang.country[ "cv" ] = "Кабо-Верде";
theUILang.country[ "cx" ] = "Остров Рождества";
theUILang.country[ "cy" ] = "Кипр";
theUILang.country[ "cz" ] = "Чехия";

theUILang.country[ "de" ] = "Германия";
theUILang.country[ "dj" ] = "Джибути";
theUILang.country[ "dk" ] = "Дания";
theUILang.country[ "dm" ] = "Доминика";
theUILang.country[ "do" ] = "Доминиканская Республика";
theUILang.country[ "dz" ] = "Алжир";

theUILang.country[ "ec" ] = "Эквадор";
theUILang.country[ "ee" ] = "Эстония";
theUILang.country[ "eg" ] = "Египет";
theUILang.country[ "eh" ] = "Западная Сахара";
theUILang.country[ "er" ] = "Эритрея";
theUILang.country[ "es" ] = "Испания";
theUILang.country[ "et" ] = "Эфиопия";
theUILang.country[ "eu" ] = "Европейский союз";

theUILang.country[ "fi" ] = "Финляндия";
theUILang.country[ "fj" ] = "Фиджи";
theUILang.country[ "fk" ] = "Фолклендские острова";
theUILang.country[ "fm" ] = "Микронезия";
theUILang.country[ "fo" ] = "Фарерские острова";
theUILang.country[ "fr" ] = "Франция";

theUILang.country[ "ga" ] = "Габон";
theUILang.country[ "gb" ] = "Великобритания";
theUILang.country[ "gd" ] = "Гренада";
theUILang.country[ "ge" ] = "Грузия";
theUILang.country[ "gf" ] = "Французская Гвиана";
theUILang.country[ "gg" ] = "Гернси";
theUILang.country[ "gh" ] = "Гана";
theUILang.country[ "gi" ] = "Гибралтар";
theUILang.country[ "gl" ] = "Гренландия";
theUILang.country[ "gm" ] = "Гамбия";
theUILang.country[ "gn" ] = "Гвинея";
theUILang.country[ "gp" ] = "Гваделупа";
theUILang.country[ "gq" ] = "Экваториальная Гвинея";
theUILang.country[ "gr" ] = "Греция";
theUILang.country[ "gs" ] = "Южная Георгия и Южные Сандвичевы острова";
theUILang.country[ "gt" ] = "Гватемала";
theUILang.country[ "gu" ] = "Гуам";
theUILang.country[ "gw" ] = "Гвинея-Бисау";
theUILang.country[ "gy" ] = "Гайана";

theUILang.country[ "hk" ] = "Гонконг";
theUILang.country[ "hm" ] = "Херд и Макдональд";
theUILang.country[ "hn" ] = "Гондурас";
theUILang.country[ "hr" ] = "Хорватия";
theUILang.country[ "ht" ] = "Гаити";
theUILang.country[ "hu" ] = "Венгрия";

theUILang.country[ "id" ] = "Индонезия";
theUILang.country[ "ie" ] = "Ирландия";
theUILang.country[ "il" ] = "Израиль";
theUILang.country[ "im" ] = "Остров Мэн";
theUILang.country[ "in" ] = "Индия";
theUILang.country[ "io" ] = "Британская территория в Индийском океане";
theUILang.country[ "iq" ] = "Ирак";
theUILang.country[ "ir" ] = "Иран";
theUILang.country[ "is" ] = "Исландия";
theUILang.country[ "it" ] = "Италия";

theUILang.country[ "je" ] = "Джерси";
theUILang.country[ "jm" ] = "Ямайка";
theUILang.country[ "jo" ] = "Иордания";
theUILang.country[ "jp" ] = "Япония";

theUILang.country[ "ke" ] = "Кения";
theUILang.country[ "kg" ] = "Киргизия";
theUILang.country[ "kh" ] = "Камбоджа";
theUILang.country[ "ki" ] = "Кирибати";
theUILang.country[ "km" ] = "Коморы";
theUILang.country[ "kn" ] = "Сент-Китс и Невис";
theUILang.country[ "kp" ] = "Северная Корея";
theUILang.country[ "kr" ] = "Южная Корея";
theUILang.country[ "kw" ] = "Кувейт";
theUILang.country[ "ky" ] = "Каймановы острова";
theUILang.country[ "kz" ] = "Казахстан";

theUILang.country[ "la" ] = "Лаос";
theUILang.country[ "lb" ] = "Ливан";
theUILang.country[ "lc" ] = "Сент-Люсия";
theUILang.country[ "li" ] = "Лихтенштейн";
theUILang.country[ "lk" ] = "Шри-Ланка";
theUILang.country[ "lr" ] = "Либерия";
theUILang.country[ "ls" ] = "Лесото";
theUILang.country[ "lt" ] = "Литва";
theUILang.country[ "lu" ] = "Люксембург";
theUILang.country[ "lv" ] = "Латвия";
theUILang.country[ "ly" ] = "Ливия";

theUILang.country[ "ma" ] = "Марокко";
theUILang.country[ "mc" ] = "Монако";
theUILang.country[ "md" ] = "Молдавия";
theUILang.country[ "me" ] = "Черногория";
theUILang.country[ "mg" ] = "Мадагаскар";
theUILang.country[ "mh" ] = "Маршалловы Острова";
theUILang.country[ "mk" ] = "Македония";
theUILang.country[ "ml" ] = "Мали";
theUILang.country[ "mm" ] = "Мьянма";
theUILang.country[ "mn" ] = "Монголия";
theUILang.country[ "mo" ] = "Аомынь";
theUILang.country[ "mp" ] = "Северные Марианские острова";
theUILang.country[ "mq" ] = "Мартиника";
theUILang.country[ "mr" ] = "Мавритания";
theUILang.country[ "ms" ] = "Монтсеррат";
theUILang.country[ "mt" ] = "Мальта";
theUILang.country[ "mu" ] = "Маврикий";
theUILang.country[ "mv" ] = "Мальдивы";
theUILang.country[ "mw" ] = "Малави";
theUILang.country[ "mx" ] = "Мексика";
theUILang.country[ "my" ] = "Малайзия";
theUILang.country[ "mz" ] = "Мозамбик";

theUILang.country[ "na" ] = "Намибия";
theUILang.country[ "nc" ] = "Новая Каледония";
theUILang.country[ "ne" ] = "Нигер";
theUILang.country[ "nf" ] = "Остров Норфолк";
theUILang.country[ "ng" ] = "Нигерия";
theUILang.country[ "ni" ] = "Никарагуа";
theUILang.country[ "nl" ] = "Нидерланды";
theUILang.country[ "no" ] = "Норвегия";
theUILang.country[ "np" ] = "Непал";
theUILang.country[ "nr" ] = "Науру";
theUILang.country[ "nu" ] = "Ниуэ";
theUILang.country[ "nz" ] = "Новая Зеландия";

theUILang.country[ "om" ] = "Оман";

theUILang.country[ "pa" ] = "Панама";
theUILang.country[ "pe" ] = "Перу";
theUILang.country[ "pf" ] = "Французская Полинезия";
theUILang.country[ "pg" ] = "Папуа — Новая Гвинея";
theUILang.country[ "ph" ] = "Филиппины";
theUILang.country[ "pk" ] = "Пакистан";
theUILang.country[ "pl" ] = "Польша";
theUILang.country[ "pm" ] = "Сен-Пьер и Микелон";
theUILang.country[ "pn" ] = "Острова Питкэрн";
theUILang.country[ "pr" ] = "Пуэрто-Рико";
theUILang.country[ "ps" ] = "Палестина";
theUILang.country[ "pt" ] = "Португалия";
theUILang.country[ "pw" ] = "Палау";
theUILang.country[ "py" ] = "Парагвай";

theUILang.country[ "qa" ] = "Катар";

theUILang.country[ "re" ] = "Реюньон";
theUILang.country[ "ro" ] = "Румыния";
theUILang.country[ "rs" ] = "Сербия";
theUILang.country[ "ru" ] = "Россия";
theUILang.country[ "rw" ] = "Руанда";

theUILang.country[ "sa" ] = "Саудовская Аравия";
theUILang.country[ "sb" ] = "Соломоновы Острова";
theUILang.country[ "sc" ] = "Сейшельские Острова";
theUILang.country[ "sd" ] = "Судан";
theUILang.country[ "se" ] = "Швеция";
theUILang.country[ "sg" ] = "Сингапур";
theUILang.country[ "sh" ] = "Остров Святой Елены";
theUILang.country[ "si" ] = "Словения";
theUILang.country[ "sj" ] = "Шпицберген и Ян-Майен";
theUILang.country[ "sk" ] = "Словакия";
theUILang.country[ "sl" ] = "Сьерра-Леоне";
theUILang.country[ "sm" ] = "Сан-Марино";
theUILang.country[ "sn" ] = "Сенегал";
theUILang.country[ "so" ] = "Сомали";
theUILang.country[ "sr" ] = "Суринам";
theUILang.country[ "ss" ] = "Южный Судан";
theUILang.country[ "st" ] = "Сан-Томе и Принсипи";
theUILang.country[ "sv" ] = "Сальвадор";
theUILang.country[ "sy" ] = "Сирия";
theUILang.country[ "sz" ] = "Свазиленд";

theUILang.country[ "tc" ] = "Тёркс и Кайкос";
theUILang.country[ "td" ] = "Чад";
theUILang.country[ "tf" ] = "Французские Южные и Антарктические Территории";
theUILang.country[ "tg" ] = "Того";
theUILang.country[ "th" ] = "Таиланд";
theUILang.country[ "tj" ] = "Таджикистан";
theUILang.country[ "tk" ] = "Токелау";
theUILang.country[ "tl" ] = "Восточный Тимор";
theUILang.country[ "tm" ] = "Туркмения";
theUILang.country[ "tn" ] = "Тунис";
theUILang.country[ "to" ] = "Тонга";
theUILang.country[ "tr" ] = "Турция";
theUILang.country[ "tp" ] = "Португальский Тимор";
theUILang.country[ "tt" ] = "Тринидад и Тобаго";
theUILang.country[ "tv" ] = "Тувалу";
theUILang.country[ "tw" ] = "Тайвань";
theUILang.country[ "tz" ] = "Танзания";

theUILang.country[ "ua" ] = "Украина";
theUILang.country[ "ug" ] = "Уганда";
theUILang.country[ "uk" ] = "Великобритания";
theUILang.country[ "um" ] = "Внешние малые острова (США)";
theUILang.country[ "un" ] = "Неизвестно";
theUILang.country[ "us" ] = "США";
theUILang.country[ "uy" ] = "Уругвай";
theUILang.country[ "uz" ] = "Узбекистан";

theUILang.country[ "va" ] = "Ватикан";
theUILang.country[ "vc" ] = "Сент-Винсент и Гренадины";
theUILang.country[ "ve" ] = "Венесуэла";
theUILang.country[ "vg" ] = "Британские Виргинские острова";
theUILang.country[ "vi" ] = "Американские Виргинские острова";
theUILang.country[ "vn" ] = "Вьетнам";
theUILang.country[ "vu" ] = "Вануату";

theUILang.country[ "wf" ] = "Уоллис и Футуна";
theUILang.country[ "ws" ] = "Самоа";

theUILang.country[ "ye" ] = "Йемен";
theUILang.country[ "yt" ] = "Майотта";

theUILang.country[ "za" ] = "ЮАР";
theUILang.country[ "zm" ] = "Замбия";
theUILang.country[ "zw" ] = "Зимбабве";

thePlugins.get("geoip").langLoaded();