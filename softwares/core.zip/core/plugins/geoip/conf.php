<?php
	// configuration parameters

	$retrieveCountry = true;
	$retrieveHost = false;

?>