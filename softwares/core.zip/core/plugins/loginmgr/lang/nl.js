﻿

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Paswoord";
 theUILang.accAccounts		= "Accounts";

thePlugins.get("loginmgr").langLoaded();