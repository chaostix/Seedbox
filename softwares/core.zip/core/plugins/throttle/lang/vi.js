﻿

 theUILang.throttles		= "Băng thông";
 theUILang.throttle		= "Băng thông";
 theUILang.mnuThrottle		= "Đặt băng thông";
 theUILang.mnuUnlimited 	= "Không có băng thông";
 theUILang.channelName		= "Tên băng thông";
 theUILang.channelDefault	= "Băng thông mặc định";

thePlugins.get("throttle").langLoaded();