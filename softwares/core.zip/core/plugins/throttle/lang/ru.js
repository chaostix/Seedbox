﻿

 theUILang.throttle		= "Канал";
 theUILang.throttles		= "Каналы";
 theUILang.mnuThrottle		= "Установить канал";
 theUILang.mnuUnlimited 	= "Отсутствует";
 theUILang.channelName		= "Имя";
 theUILang.channelDefault	= "Канал по умолчанию";

thePlugins.get("throttle").langLoaded();