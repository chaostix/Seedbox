﻿/*
 * PLUGIN THROTTLE
 *
 * File Name: fr.js
 * 	French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.throttles		= "Vitesses";
 theUILang.throttle		= "Vitesse";
 theUILang.mnuThrottle		= "Affecter une vitesse";
 theUILang.mnuUnlimited 	= "Pas de restriction";
 theUILang.channelName		= "Nom";
 theUILang.channelDefault	= "Vitesse par défaut";

thePlugins.get("throttle").langLoaded();