﻿

 theUILang.throttle		= "Канал";
 theUILang.throttles		= "Канали";
 theUILang.mnuThrottle		= "Установити канал";
 theUILang.mnuUnlimited 	= "Немає";
 theUILang.channelName		= "Назва";
 theUILang.channelDefault	= "Стандартний канал";

thePlugins.get("throttle").langLoaded();