﻿

 theUILang.throttles		= "Канали";
 theUILang.throttle		= "Канал";
 theUILang.mnuThrottle		= "Постави канал";
 theUILang.mnuUnlimited 	= "Нема канала";
 theUILang.channelName		= "Име";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();