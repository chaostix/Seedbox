<?php

$theUILang["all"]		= "All torrents";
$theUILang["completed"] 	= "Completed torrents";
$theUILang["downloading"]	= "Downloading torrents";
$theUILang["active"]		= "Active torrents";
$theUILang["inactive"]		= "Inactive torrents";
$theUILang["error"]		= "Error torrents";
$theUILang["Transfer"]		= "Transfer";
$theUILang["Size"]		= "Size";
$theUILang["Remaining"] 	= "Remaining";
$theUILang["Share_ratio"]	= "Share Ratio";
$theUILang["Downloaded"]	= "Downloaded"; 
$theUILang["Down_speed"]	= "Download Speed";
$theUILang["Uploaded"]		= "Uploaded";
$theUILang["Ul_speed"]		= "Upload Speed";
$theUILang["Seeds"]		= "Seeds";
$theUILang["Peers"]		= "Peers";
$theUILang["Track_status"]	= "Tracker Status";
$theUILang["Comment"]		= "Comment";
$theUILang["s"] 		= "s";
$theUILang["bytes"]		= "bytes";
$theUILang["KB"]		= "KB";
$theUILang["MB"]		= "MB";
$theUILang["GB"]		= "GB";
$theUILang["TB"]		= "TB";
$theUILang["PB"]		= "PB";
$theUILang["time_w"]		= "w ";
$theUILang["time_d"]		= "d ";
$theUILang["time_h"]		= "h ";
$theUILang["time_m"]		= "m ";
$theUILang["time_s"]		= "s ";

?>