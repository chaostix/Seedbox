<?php

$theUILang["all"]		= "Все закачки";
$theUILang["completed"] 	= "Завершенные закачки";
$theUILang["downloading"]	= "Загружаемые закачки";
$theUILang["active"]		= "Активные закачки";
$theUILang["inactive"]		= "Неактивные закачки";
$theUILang["error"]		= "Закачки с ошибками";
$theUILang["Transfer"]		= "Передача";
$theUILang["Size"]		= "Размер";
$theUILang["Remaining"] 	= "Осталось";
$theUILang["Share_ratio"]	= "Ратио";
$theUILang["Downloaded"]	= "Загружено"; 
$theUILang["Down_speed"]	= "Скорость скачивания";
$theUILang["Uploaded"]		= "Отдано";
$theUILang["Ul_speed"]		= "Скорость отдачи";
$theUILang["Seeds"]		= "Сиды";
$theUILang["Peers"]		= "Пиры";
$theUILang["Track_status"]	= "Статус трекера";
$theUILang["Comment"]		= "Комментарий";
$theUILang["s"] 		= "с";
$theUILang["bytes"]		= "байт";
$theUILang["KB"]		= "КБ";
$theUILang["MB"]		= "МБ";
$theUILang["GB"]		= "ГБ";
$theUILang["TB"]		= "ТБ";
$theUILang["PB"]		= "ПБ";
$theUILang["time_w"]		= "н ";
$theUILang["time_d"]		= "д ";
$theUILang["time_h"]		= "ч ";
$theUILang["time_m"]		= "м ";
$theUILang["time_s"]		= "с ";

?>