﻿/*
 * PLUGIN FEEDS
 *
 * File Name: fr.js
 * 	French language file.
 *
 * File Author:
 *    Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.feedAll		= "Tous les torrents";
 theUILang.feedCompleted	= "Torrents terminés";
 theUILang.feedDownloading	= "Torrents en cours de téléchargement";
 theUILang.feedActive		= "Torrents actifs";
 theUILang.feedInactive 	= "Torrents inactifs";
 theUILang.feedError		= "Torrents en erreur";

thePlugins.get("feeds").langLoaded();