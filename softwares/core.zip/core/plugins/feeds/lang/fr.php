<?php

$theUILang["all"]		= "Tous les torrents";
$theUILang["completed"] 	= "Torrents terminés";
$theUILang["downloading"]	= "Torrents en cours de téléchargement";
$theUILang["active"]		= "Torrents actifs";
$theUILang["inactive"]		= "Torrents inactifs";
$theUILang["error"]		= "Torrents en erreur";
$theUILang["Transfer"]		= "Transfert";
$theUILang["Size"]		= "Taille";
$theUILang["Remaining"] 	= "Remaining";
$theUILang["Share_ratio"]	= "Ratio";
$theUILang["Downloaded"]	= "Téléchargé"; 
$theUILang["Down_speed"]	= "Vitesse de réception";
$theUILang["Uploaded"]		= "Envoyé";
$theUILang["Ul_speed"]		= "Vitesse d'envoi";
$theUILang["Seeds"]		= "Sources";
$theUILang["Peers"]		= "Clients";
$theUILang["Track_status"]	= "Status du tracker";
$theUILang["Comment"]		= "Commentaire";
$theUILang["s"] 		= "s";
$theUILang["bytes"]		= "bytes";
$theUILang["KB"]		= "Ko";
$theUILang["MB"]		= "Mo";
$theUILang["GB"]		= "Go";
$theUILang["TB"]		= "To";
$theUILang["PB"]		= "Po";
$theUILang["time_w"]		= "sem ";
$theUILang["time_d"]		= "jrs ";
$theUILang["time_h"]		= "h ";
$theUILang["time_m"]		= "m ";
$theUILang["time_s"]		= "s ";

?>