﻿

 theUILang.feedAll		= "Alle Torrents";
 theUILang.feedCompleted	= "Voltooide Torrents";
 theUILang.feedDownloading	= "Torrents aan het Downloaden";
 theUILang.feedActive		= "Actieve Torrents";
 theUILang.feedInactive 	= "Inactieve Torrents";
 theUILang.feedError		= "Foutieve Torrents";

thePlugins.get("feeds").langLoaded();