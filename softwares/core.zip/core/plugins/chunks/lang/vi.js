﻿

 theUILang.Chunks		= "Các khối";
 theUILang.chunksNoChunksFound	= "Không tìm thấy khối!";
 theUILang.chunksRows		= "hàng";
 theUILang.chunksColumns	= "cột";
 theUILang.chunksChunks 	= "khối";
 theUILang.chunksSize		= "kích thước khối";

thePlugins.get("chunks").langLoaded();