﻿

 theUILang.Chunks		= "块";
 theUILang.chunksNoChunksFound	= "没有找到块!";
 theUILang.chunksRows		= "行";
 theUILang.chunksColumns	= "列";
 theUILang.chunksChunks 	= "块";
 theUILang.chunksSize		= "块尺寸";

thePlugins.get("chunks").langLoaded();