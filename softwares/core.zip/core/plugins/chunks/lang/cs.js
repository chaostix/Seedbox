﻿

 theUILang.Chunks		= "Chunks";
 theUILang.chunksNoChunksFound	= "No chunks found!";
 theUILang.chunksRows		= "row(s)";
 theUILang.chunksColumns	= "column(s)";
 theUILang.chunksChunks 	= "chunk(s)";
 theUILang.chunksSize		= "chunk size";

thePlugins.get("chunks").langLoaded();