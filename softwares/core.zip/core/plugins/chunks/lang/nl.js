﻿

 theUILang.Chunks		= "chunks";
 theUILang.chunksNoChunksFound	= "Geen brokken gevonden!";
 theUILang.chunksRows		= "rij (s)";
 theUILang.chunksColumns	= "kolom (s)";
 theUILang.chunksChunks 	= "Brokken (s)";
 theUILang.chunksSize		= "Brok grote";

thePlugins.get("chunks").langLoaded();