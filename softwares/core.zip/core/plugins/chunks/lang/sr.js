﻿

 theUILang.Chunks		= "Парчад";
 theUILang.chunksNoChunksFound	= "Нема парчади!";
 theUILang.chunksRows		= "врста";
 theUILang.chunksColumns	= "колона";
 theUILang.chunksChunks 	= "парчади";
 theUILang.chunksSize		= "величина парчета";

thePlugins.get("chunks").langLoaded();