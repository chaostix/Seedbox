﻿

 theUILang.Chunks		= "Части";
 theUILang.chunksNoChunksFound	= "Информации о частях нет.";
 theUILang.chunksRows		= "строки";
 theUILang.chunksColumns	= "колонки";
 theUILang.chunksChunks 	= "части";
 theUILang.chunksSize		= "размер части";

thePlugins.get("chunks").langLoaded();
