﻿

 theUILang.Chunks		= "Частини";
 theUILang.chunksNoChunksFound	= "Відомостей про частини немає.";
 theUILang.chunksRows		= "рядки";
 theUILang.chunksColumns	= "стовпці";
 theUILang.chunksChunks 	= "частини";
 theUILang.chunksSize		= "розмір частини";

thePlugins.get("chunks").langLoaded();
