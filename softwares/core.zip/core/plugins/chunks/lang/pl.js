﻿

 theUILang.Chunks		= "Kawałki(Chunks)";
 theUILang.chunksNoChunksFound	= "Brak kawałków (chunks)!";
 theUILang.chunksRows		= "wierszy";
 theUILang.chunksColumns	= "kolumn";
 theUILang.chunksChunks 	= "kawałków";
 theUILang.chunksSize		= "rozmiar kawałka(chunk)";

thePlugins.get("chunks").langLoaded();
