﻿

 theUILang.checkPort		= "Sprawdź status przekierowania Portu/Portów";
 theUILang.portStatus		= [
 				  "Port status nieznany",
 				  "Port zamknięty",
 				  "Port otwarty.OK"
 				  ];

thePlugins.get("check_port").langLoaded();
