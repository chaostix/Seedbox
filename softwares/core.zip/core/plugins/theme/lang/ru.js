﻿

 theUILang.themeStandard	= "Стандартная";
 theUILang.theme		= "Палитра";

thePlugins.get("theme").langLoaded();